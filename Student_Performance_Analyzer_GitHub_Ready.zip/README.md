# 🎓 Student Performance Analyzer & Predictor

👤 Author: Karan  
🎯 Goal: Analyze and predict whether a student will pass based on academic metrics using pandas, seaborn, matplotlib, sklearn.

## 📁 Project Structure
```
Student-Performance-Analyzer/
├── data/
│   └── students.csv           # <- Download and place the dataset here
├── Student_Performance_Analyzer_Karan.ipynb
├── requirements.txt
├── README.md
└── .gitignore
```

## 🚀 How to Run
1. Install dependencies:
```
pip install -r requirements.txt
```

2. Open the notebook:
```
jupyter notebook Student_Performance_Analyzer_Karan.ipynb
```

## 📊 Dataset
Download `student-mat.csv` from the [UCI ML Repo](https://archive.ics.uci.edu/ml/machine-learning-databases/00320/student.zip)  
Rename it to `students.csv` and place it inside the `data/` folder.

## ✅ Features
- Logistic regression model
- Pass/fail classification
- Correlation heatmaps
- Seaborn/matplotlib visualizations
